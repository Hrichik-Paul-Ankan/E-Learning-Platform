
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>




	    <center><img  width="200" height="200" src="image.png" ></center> 
	    <p align="center" ><b>
	        <a href="homepage.php" style="font-size:18px" >Home</a>&nbsp;&nbsp;&nbsp;
	        <a href="login.php" style="font-size:18px" >Login</a>&nbsp;&nbsp;&nbsp;
	        <a href="registration.php" style="font-size:18px" >Register</a>
	    </p> 
	<hr/>
