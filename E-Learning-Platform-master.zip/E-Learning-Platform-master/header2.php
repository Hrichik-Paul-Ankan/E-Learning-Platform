
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<b>



<?php
	echo '
	    
	    <center><img  width="200" height="200" src="image.png" ></center> 
	    <p align="center" >
	        <a href="homepage2.php" style="font-size:18px" >Home</a>&nbsp;&nbsp;&nbsp;
	         <a href="dashboard.php" style="font-size:18px" >Dashboard</a>&nbsp;&nbsp;&nbsp;
	        <a href="coursemng.php" style="font-size:18px" >Course Management</a>&nbsp;&nbsp;&nbsp;
	        <a href="Student.php" style="font-size:18px" >Student</a>&nbsp;&nbsp;&nbsp;
	        <a href="mentor.php" style="font-size:18px" >Mentor</a>&nbsp;&nbsp;&nbsp;
	        <a href="payment.php" style="font-size:18px" >Payment</a>&nbsp;&nbsp;&nbsp;
	        <a href="profile.php" style="font-size:18px" >My Profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="logout.php" style="font-size:18px" >Log Out</a>
	    </p> 
	<hr/>
	';

?>