
<!DOCTYPE html>

<html lang="en">
<head>
    <title></title>
</head>


 <?php include('header.php')?>
<body>

        <p><br></p><p><br></p>
        <table align="center" border="8px" style="padding: 15px;">
            <tr>
                <td>
                    <h2 align="center">Welcome</h2> 
                    <h2 align="center">To</h2>
                    <h2 align="center">"Efficient Learning"</h2>
                </td>
            </tr>
        </table>

    
    <p><br></p><p><br></p>
    
</body>

<?php include('footer.php')?>

</html>

