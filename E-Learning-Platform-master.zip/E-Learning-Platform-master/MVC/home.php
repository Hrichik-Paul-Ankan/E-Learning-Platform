<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
     <a href="Controllers/loginController.php">Registration</a>
</body>
</html>