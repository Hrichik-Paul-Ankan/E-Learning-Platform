
<?php
session_start();
?>


<!DOCTYPE html>
<html>

 <?php include('header.php')?>


 <p><br></p><p><br></p><p><br></p>

<span style="color: green"> <b> <h1 align="center"><?php echo  "Successfully Completed ";?></h1> </span>

<body>





</body>

<p><br></p><p><br></p><p><br></p><p><br></p>
<?php include('footer.php')?>
</html>