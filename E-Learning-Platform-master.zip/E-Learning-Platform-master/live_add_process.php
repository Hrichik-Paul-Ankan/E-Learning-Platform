<!DOCTYPE html>
<html>
<head>
    <title>Add Live Course</title>
</head>
<body>

    <h1>Add New Live Course</h1>

    <form action="live_course_add.php" method="post">
        Course ID: <input type="text" name="course_id"><br><br>
        Course Name: <input type="text" name="course_name"><br><br>
        Time: <input type="text" name="course_time"><br><br>
        <input type="submit" value="Add Live Course">
    </form>

</body>
</html>